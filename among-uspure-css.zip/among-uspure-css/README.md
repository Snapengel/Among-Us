# Among Us - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Mamboleoo/pen/WNxOvjo](https://codepen.io/Mamboleoo/pen/WNxOvjo).

Ejection animation from Among Us in pure CSS.